'use strict';

require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const SESSION_SECRET = process.env.SESSION_SECRET || '';
const COOKIE_SECURE = String(process.env.COOKIE_SECURE || 'false').toLowerCase() === 'true';
const DB_PATH = process.env.DB_PATH || './data/garet.sqlite';

if (ADMIN_PASSWORD.length < 14 || SESSION_SECRET.length < 32) {
  console.error('Configuration error: set ADMIN_PASSWORD (14+ chars) and SESSION_SECRET (32+ chars) in .env.');
  process.exit(1);
}

const resolvedDb = path.resolve(DB_PATH);
fs.mkdirSync(path.dirname(resolvedDb), { recursive: true });
const db = new Database(resolvedDb);
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS recipients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT NOT NULL,
    amount TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','paid','failed')),
    tx_hash TEXT,
    note TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    recipient_id INTEGER,
    detail TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: '30kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Too many login attempts. Try again later.' }
});

function safeEqual(a, b) {
  const ah = crypto.createHash('sha256').update(String(a)).digest();
  const bh = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ah, bh);
}
function sign(value) {
  return crypto.createHmac('sha256', SESSION_SECRET).update(value).digest('hex');
}
function createSession() {
  const payload = Buffer.from(JSON.stringify({ exp: Date.now() + 8 * 60 * 60 * 1000 })).toString('base64url');
  return `${payload}.${sign(payload)}`;
}
function isAuthenticated(req) {
  const token = req.headers.cookie?.split(';').map(v => v.trim()).find(v => v.startsWith('garet_admin='));
  if (!token) return false;
  const raw = token.slice('garet_admin='.length);
  const parts = raw.split('.');
  if (parts.length !== 2) return false;
  const [payload, signature] = parts;
  if (!safeEqual(signature, sign(payload))) return false;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    return Number(data.exp) > Date.now();
  } catch { return false; }
}
function requireAdmin(req, res, next) {
  if (!isAuthenticated(req)) return res.status(401).json({ error: 'Admin login required.' });
  next();
}
function audit(action, recipientId, detail) {
  db.prepare('INSERT INTO audit_log (action, recipient_id, detail) VALUES (?, ?, ?)')
    .run(action, recipientId || null, String(detail || '').slice(0, 500));
}
function validAddress(address) {
  return /^0x[a-fA-F0-9]{40}$/.test(String(address || '').trim());
}
function validTxHash(hash) {
  return /^0x[a-fA-F0-9]{64}$/.test(String(hash || '').trim());
}

app.get('/api/public/config', (_req, res) => {
  res.json({
    name: 'GARET',
    version: 'Draft v1.0',
    network: 'BNB Smart Chain (BEP-20)',
    contract: '0x4af74098468daaa01f422f6f367e2e09ecf425fc',
    totalSupply: '1,000,000,000 GARET',
    allocations: [
      { name: 'Airdrop', percent: 30, amount: '300,000,000' },
      { name: 'Community Rewards', percent: 20, amount: '200,000,000' },
      { name: 'Ecosystem', percent: 20, amount: '200,000,000' },
      { name: 'Team', percent: 15, amount: '150,000,000' },
      { name: 'Liquidity', percent: 15, amount: '150,000,000' }
    ],
    notice: 'Project plans and contract address are user-provided and have not been independently verified by this website.'
  });
});

app.post('/api/admin/login', loginLimiter, (req, res) => {
  const password = String(req.body?.password || '');
  if (!safeEqual(password, ADMIN_PASSWORD)) {
    audit('login_failed', null, 'Invalid password');
    return res.status(401).json({ error: 'Incorrect password.' });
  }
  const token = createSession();
  res.setHeader('Set-Cookie',
    `garet_admin=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${COOKIE_SECURE ? '; Secure' : ''}`);
  audit('login_success', null, 'Admin login');
  res.json({ ok: true });
});

app.post('/api/admin/logout', (_req, res) => {
  res.setHeader('Set-Cookie', `garet_admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${COOKIE_SECURE ? '; Secure' : ''}`);
  res.json({ ok: true });
});

app.get('/api/admin/session', requireAdmin, (_req, res) => res.json({ ok: true }));

app.get('/api/admin/recipients', requireAdmin, (_req, res) => {
  const rows = db.prepare('SELECT id, address, amount, status, tx_hash, note, created_at, updated_at FROM recipients ORDER BY id DESC').all();
  res.json({ recipients: rows });
});

app.post('/api/admin/recipients', requireAdmin, (req, res) => {
  const address = String(req.body?.address || '').trim();
  const amount = String(req.body?.amount || '').trim();
  const note = String(req.body?.note || '').trim().slice(0, 300);
  if (!validAddress(address)) return res.status(400).json({ error: 'Wallet address must be a valid 0x address (42 characters).' });
  if (!/^\d+(\.\d{1,18})?$/.test(amount) || Number(amount) <= 0 || amount.length > 40) {
    return res.status(400).json({ error: 'Amount must be a positive number.' });
  }
  const result = db.prepare('INSERT INTO recipients (address, amount, note) VALUES (?, ?, ?)').run(address, amount, note);
  audit('recipient_created', result.lastInsertRowid, `Added ${address}, amount ${amount}`);
  res.status(201).json({ ok: true, id: result.lastInsertRowid });
});

app.patch('/api/admin/recipients/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid recipient ID.' });
  const existing = db.prepare('SELECT * FROM recipients WHERE id = ?').get(id);
  if (!existing) return res.status(404).json({ error: 'Recipient not found.' });

  const status = String(req.body?.status || existing.status);
  const txHash = String(req.body?.tx_hash ?? existing.tx_hash ?? '').trim();
  const note = String(req.body?.note ?? existing.note ?? '').trim().slice(0, 300);
  if (!['pending', 'paid', 'failed'].includes(status)) return res.status(400).json({ error: 'Invalid status.' });
  if (status === 'paid' && !validTxHash(txHash)) {
    return res.status(400).json({ error: 'To mark Paid, enter a 0x transaction hash (66 characters) after sending the transfer.' });
  }
  if (txHash && !validTxHash(txHash)) return res.status(400).json({ error: 'Transaction hash format is invalid.' });

  db.prepare("UPDATE recipients SET status = ?, tx_hash = ?, note = ?, updated_at = datetime('now') WHERE id = ?")
    .run(status, txHash || null, note, id);
  audit('recipient_updated', id, `Status=${status}; tx=${txHash || 'none'}`);
  res.json({ ok: true });
});

app.delete('/api/admin/recipients/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid recipient ID.' });
  const result = db.prepare('DELETE FROM recipients WHERE id = ?').run(id);
  if (!result.changes) return res.status(404).json({ error: 'Recipient not found.' });
  audit('recipient_deleted', id, 'Recipient removed');
  res.json({ ok: true });
});

app.get('/api/admin/export.csv', requireAdmin, (_req, res) => {
  const rows = db.prepare('SELECT id, address, amount, status, tx_hash, note, created_at, updated_at FROM recipients ORDER BY id ASC').all();
  const cols = ['id','address','amount','status','tx_hash','note','created_at','updated_at'];
  const esc = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const csv = [cols.join(','), ...rows.map(row => cols.map(c => esc(row[c])).join(','))].join('\r\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="garet-airdrop-recipients.csv"');
  res.send('\uFEFF' + csv);
});

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get('/admin', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => console.log(`GARET website running on port ${PORT}`));
